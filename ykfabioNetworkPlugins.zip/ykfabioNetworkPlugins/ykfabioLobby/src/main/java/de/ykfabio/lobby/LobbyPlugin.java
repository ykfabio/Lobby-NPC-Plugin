package de.ykfabio.lobby;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class LobbyPlugin extends JavaPlugin implements Listener, PluginMessageListener {
    private final Map<UUID, Long> lastMenu = new HashMap<>();
    private final Set<UUID> hiddenPlayers = new HashSet<>();
    private static final String MENU = ChatColor.DARK_GRAY + "Navigator";
    @Override public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
        getServer().getMessenger().registerIncomingPluginChannel(this, "BungeeCord", this);
        Objects.requireNonNull(getCommand("lobby")).setExecutor(this::command);
        Objects.requireNonNull(getCommand("spawn")).setExecutor(this::command);
        Objects.requireNonNull(getCommand("setspawn")).setExecutor(this::command);
        Objects.requireNonNull(getCommand("setlobby")).setExecutor(this::command);
        getLogger().info("ykfabioLobby aktiviert.");
    }
    private boolean command(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("lobby")) {
            if (args.length == 1 && args[0].equalsIgnoreCase("reload")) { if (!admin(sender)) return noPerm(sender); reloadConfig(); sender.sendMessage(color("&aConfig neu geladen.")); return true; }
            if (!(sender instanceof Player p)) { sender.sendMessage("Nur Spieler."); return true; }
            connect(p, getConfig().getString("network.lobby-server", "lobby")); return true;
        }
        if (!(sender instanceof Player p)) { sender.sendMessage("Nur Spieler."); return true; }
        if (cmd.getName().equalsIgnoreCase("spawn")) { teleport(p, "locations.spawn"); return true; }
        if (!admin(sender)) return noPerm(sender);
        if (cmd.getName().equalsIgnoreCase("setlobby")) { saveLocation("locations.lobby", p.getLocation()); p.sendMessage(color("&aLobby-Spawn gespeichert.")); }
        else if (cmd.getName().equalsIgnoreCase("setspawn")) { saveLocation("locations.spawn", p.getLocation()); p.sendMessage(color("&aSpawn gespeichert.")); }
        return true;
    }
    private void saveLocation(String path, Location l) { getConfig().set(path + ".world", l.getWorld().getName()); getConfig().set(path + ".x", l.getX()); getConfig().set(path + ".y", l.getY()); getConfig().set(path + ".z", l.getZ()); getConfig().set(path + ".yaw", l.getYaw()); getConfig().set(path + ".pitch", l.getPitch()); saveConfig(); }
    private void teleport(Player p, String path) { String w=getConfig().getString(path+".world"); World world=Bukkit.getWorld(w==null?"":w); if(world==null){p.sendMessage(color("&cSpawn ist nicht gesetzt."));return;} Location l=new Location(world,getConfig().getDouble(path+".x"),getConfig().getDouble(path+".y"),getConfig().getDouble(path+".z"),(float)getConfig().getDouble(path+".yaw"),(float)getConfig().getDouble(path+".pitch")); p.teleport(l); }
    private void connect(Player p, String server) { if (server.equalsIgnoreCase("local")) { teleport(p,"locations.lobby"); return; } try { ByteArrayOutputStream b=new ByteArrayOutputStream(); DataOutputStream out=new DataOutputStream(b); out.writeUTF("Connect"); out.writeUTF(server); p.sendPluginMessage(this,"BungeeCord",b.toByteArray()); } catch(IOException ex){p.sendMessage(color("&cServerwechsel fehlgeschlagen."));} }
    @Override public void onPluginMessageReceived(String channel, Player player, byte[] message) { }
    @EventHandler public void onJoin(PlayerJoinEvent e) { Player p=e.getPlayer(); if(getConfig().getBoolean("join.clear-inventory",true)) p.getInventory().clear(); giveLobbyItems(p); if(getConfig().getBoolean("join.teleport-to-lobby",true)) Bukkit.getScheduler().runTask(this,()->teleport(p,"locations.lobby")); }
    private void giveLobbyItems(Player p) { if(!getConfig().getBoolean("join.give-items",true))return; ItemStack compass=new ItemStack(Material.COMPASS); ItemMeta meta=compass.getItemMeta(); meta.setDisplayName(color("&b&lNavigator")); meta.setLore(List.of(color("&7Rechtsklick zum Öffnen"))); if(getConfig().getBoolean("navigator.glow",true)) meta.addEnchant(org.bukkit.enchantments.Enchantment.LUCK_OF_THE_SEA,1,true); compass.setItemMeta(meta); p.getInventory().setItem(getConfig().getInt("navigator.slot",4),compass); ItemStack visibility=new ItemStack(Material.CLOCK); ItemMeta vm=visibility.getItemMeta(); vm.setDisplayName(color("&e&lSpieler anzeigen/verstecken")); visibility.setItemMeta(vm); p.getInventory().setItem(8,visibility); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { if(e.getItem()!=null && e.getAction().isRightClick() && e.getItem().getType()==Material.COMPASS && getConfig().getBoolean("navigator.enabled",true)){ e.setCancelled(true); openMenu(e.getPlayer()); } else if(e.getItem()!=null && e.getAction().isRightClick() && e.getItem().getType()==Material.CLOCK){ e.setCancelled(true); Player p=e.getPlayer(); boolean hidden=hiddenPlayers.remove(p.getUniqueId()); if(!hidden){hiddenPlayers.add(p.getUniqueId()); for(Player other:Bukkit.getOnlinePlayers())if(!other.equals(p))p.hidePlayer(this,other);p.sendMessage(color("&eSpieler ausgeblendet."));}else{for(Player other:Bukkit.getOnlinePlayers())if(!other.equals(p))p.showPlayer(this,other);p.sendMessage(color("&aSpieler eingeblendet."));} } }
    private void openMenu(Player p) { Inventory inv=Bukkit.createInventory(null,27,MENU); set(inv,10,Material.COMPASS,"&b&lLobby","&7Zum Lobby-Spawn"); set(inv,13,Material.GRASS_BLOCK,"&a&lCityBuild","&7Zum CityBuild-Netzwerkserver"); set(inv,16,Material.BARRIER,"&c&lComing Soon","&7Demnächst verfügbar"); p.openInventory(inv); }
    private void set(Inventory inv,int slot,Material mat,String name,String lore){ItemStack it=new ItemStack(mat);ItemMeta m=it.getItemMeta();m.setDisplayName(color(name));m.setLore(List.of(color(lore)));it.setItemMeta(m);inv.setItem(slot,it);}
    @EventHandler public void onMenuClick(InventoryClickEvent e) { if(e.getView().getTitle().equals(MENU)){e.setCancelled(true);if(!(e.getWhoClicked() instanceof Player p)||e.getCurrentItem()==null)return;switch(e.getRawSlot()){case 10 -> connect(p,getConfig().getString("network.lobby-server","lobby"));case 13 -> connect(p,getConfig().getString("network.citybuild-server","citybuild"));case 16 -> p.sendMessage(color("&eDieser Modus kommt bald!"));default -> {}}} }
    @EventHandler public void onDrop(PlayerDropItemEvent e){if(protect("anti-drop")&&!bypass(e.getPlayer()))e.setCancelled(true);}
    @EventHandler public void onPickup(EntityPickupItemEvent e){if(e.getEntity() instanceof Player p && protect("anti-pickup")&&!bypass(p))e.setCancelled(true);}
    @EventHandler public void onBreak(BlockBreakEvent e){if(protect("block-break")&&!bypass(e.getPlayer()))e.setCancelled(true);}
    @EventHandler public void onPlace(BlockPlaceEvent e){if(protect("block-place")&&!bypass(e.getPlayer()))e.setCancelled(true);}
    @EventHandler public void onDamage(EntityDamageEvent e){if(e.getEntity() instanceof Player p && protect("no-damage")&&!bypass(p))e.setCancelled(true);}
    @EventHandler public void onFood(FoodLevelChangeEvent e){if(e.getEntity() instanceof Player p && protect("no-hunger")&&!bypass(p))e.setCancelled(true);}
    @EventHandler public void onVoid(PlayerMoveEvent e){if(!getConfig().getBoolean("protection.void-protection",true)||bypass(e.getPlayer())||e.getTo()==null||e.getTo().getY()>getConfig().getDouble("protection.void-y",-10))return; teleport(e.getPlayer(),"locations.lobby");}
    @EventHandler public void onPvP(EntityDamageByEntityEvent e){if(e.getEntity() instanceof Player && e.getDamager() instanceof Player attacker && protect("pvp")&&!bypass(attacker))e.setCancelled(true);}
    @EventHandler public void onWeather(WeatherChangeEvent e){if(getConfig().getBoolean("extras.lock-weather",true))e.setCancelled(true);}
    @EventHandler public void onVisibility(PlayerJoinEvent e){if(getConfig().getBoolean("extras.hide-players",false)){hiddenPlayers.add(e.getPlayer().getUniqueId());for(Player other:Bukkit.getOnlinePlayers())if(!other.equals(e.getPlayer()))e.getPlayer().hidePlayer(this,other);}}
    private boolean protect(String key){return getConfig().getBoolean("protection."+key,true);}
    private boolean admin(CommandSender s){
        if(s instanceof Player p && rankHasPermission(p,"ranksystem.admin")) return true;
        return s.hasPermission("ranksystem.admin")||s.hasPermission("ykfabio.lobby.admin")||s.hasPermission("ykfabio.lobby.bypass")||s.isOp();
    }
    private boolean bypass(Player p){return getConfig().getBoolean("protection.admin-bypass",true) && (rankHasPermission(p,"ranksystem.admin") || p.hasPermission("ykfabio.lobby.bypass") || p.isOp());}
    private boolean rankHasPermission(Player player,String permission){
        try {
            for(org.bukkit.plugin.Plugin plugin:Bukkit.getPluginManager().getPlugins()) {
                if(!plugin.getClass().getName().equals("de.ykfabio.ranksystem.paper.RankSystemPaper")) continue;
                java.lang.reflect.Method accessor=plugin.getClass().getDeclaredMethod("manager"); accessor.setAccessible(true);
                Object manager=accessor.invoke(plugin);
                java.lang.reflect.Method check=manager.getClass().getMethod("hasPermission",UUID.class,String.class);
                return Boolean.TRUE.equals(check.invoke(manager,player.getUniqueId(),permission));
            }
        } catch(ReflectiveOperationException | RuntimeException ex) { getLogger().warning("RankSystem-API konnte nicht abgefragt werden: "+ex.getMessage()); }
        return player.hasPermission(permission);
    }
    private boolean noPerm(CommandSender s){s.sendMessage(color("&cKeine Berechtigung."));return true;}
    private String color(String s){return ChatColor.translateAlternateColorCodes('&',s);}
}
